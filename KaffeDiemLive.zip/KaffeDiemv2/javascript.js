// Oppsett av server og autentisering
const express = require('express');
const app = express();
const port = 3000;
const { data, error } = require('jquery');
const session = require('express-session');
const bodyParser = require('body-parser');
const wss = new (require('ws')).Server({port: 80});

app.set('view engine', 'ejs');
app.use(express.static('public'));
app.use(bodyParser.json());
app.listen(port, () => {
  console.log(`Example app listening at http://localhost:${port}`)
});

const passord = 'FlyvendeBestemor' // Passordet som vil blir brukt til autentisering

app.use(session({
  genid: function (req) {
    return Date.now().toString();
  },
  secret: 'daijeun3843nuewn98a38n',
  resave: false,
  saveUninitialized: true,
  cookie: {secure: false}
}))


function renderPage() {
  // Interface
  app.get('/', function(req, res) {
    if (req.session.passord != passord) {
      res.redirect('/login')
    }
    else {
      res.render('pages/interface', {
        pendingOrders: orders.pendingOrders,
        completeOrders: orders.completeOrders
      });
    }
  });
  // Display
  app.get('/display', function(req, res) {
    res.render('pages/display', {
      pendingOrders: orders.pendingOrders,
      completeOrders: orders.completeOrders
    });
  });
  // Login
  app.get('/login', function (req, res) {
    res.render('pages/login')
  })
}

// Server lagring
let orders = {
  orderNumber: 0,
  pendingOrders: [],
  completeOrders: [],

  addOrderToArray() {
    this.orderNumber += 1;
    this.pendingOrders.push(this.orderNumber);
    oppdateringer.push({id: this.orderNumber, operasjon: 'opprett'});
    renderPage();
    return this.orderNumber;
  },

  completeOrder(orderId) {
    if (orderId == null || orderId == NaN || this.pendingOrders.indexOf(orderId) === -1) {
      return;
    }

    this.pendingOrders.splice(this.pendingOrders.indexOf(orderId), 1);
    this.completeOrders.push(orderId);
    oppdateringer.push({id: orderId, operasjon: 'flytt'});
    renderPage();
    return orderId;
  },

  removeOrder(orderId) {
    this.completeOrders.splice(this.completeOrders.indexOf(orderId), 1);
    oppdateringer.push({id: orderId, operasjon: 'slett'})
    renderPage();
    return orderId;
  }
}

// Login
app.route('/login').post(function (req, res) {

  if (req.session.timeOut > Date.now()) return res.send({feilmelding: 'For raskt'});

  req.session.timeOut = Date.now() + 2000;
  req.session.passord = req.body.passord;

  if (req.session.passord != passord) {
    return res.send({feilmelding: 'Feil passord'});
  }

  res.send();
});

// Interface
app.route('').post(function (req, res) {

  if (req.session.passord != passord) return res.send();

  if (req.body.operasjon === 'nyOrdre') {
    res.send({
      id: orders.addOrderToArray()
    });
  }

  if (req.body.operasjon === 'fullførOrdre') {
    res.send({
      id: orders.completeOrder(Number(req.body.id))
    });
  }

  if (req.body.operasjon === 'slettOrdre') {
    res.send({
      id: orders.removeOrder(Number(req.body.id))
    });
  }
});

// Display
let oppdateringer = [];

setInterval(function () {
  if (oppdateringer.length == 0) return;
  const senderOppdateringer = oppdateringer;
  wss.clients.forEach(function (client) {
    client.send(JSON.stringify(senderOppdateringer));
  });
  oppdateringer.splice(0, senderOppdateringer.length);
}, 5000);

renderPage();