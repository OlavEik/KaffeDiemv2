let lages = document.getElementById('lages');
let ferdig = document.getElementById('ferdig');

$(document).ready(function () {
    $('#nyOrdre').on('click', function () {
        $.ajax({
            url: '',
            method: 'POST',
            contentType: 'application/json',
            data: JSON.stringify({operasjon: 'nyOrdre'}),
            success: function (res) {
                let ordreElement = document.createElement('p');
                ordreElement.innerHTML = ('000' + res.id).slice(-3);
                ordreElement.id = res.id;
                ordreElement.addEventListener('click', fullførOrdre);
                lages.appendChild(ordreElement);
            }
        })
    })
});

let lagesElementer = document.getElementById('lages').querySelectorAll('p');

function fullførOrdre(evt) {
    $.ajax({
        url: '',
        method: 'POST',
        contentType: 'application/json',
        data: JSON.stringify({operasjon: 'fullførOrdre', id: evt.target.id}),
        success: function (res) {
            evt.target.remove();
            if (res.id == undefined) return;
            let ordreElement = document.createElement('p');
            ordreElement.innerHTML = ('000' + res.id).slice(-3);
            ordreElement.id = res.id;
            ordreElement.addEventListener('click', slettOrdre);
            ferdig.appendChild(ordreElement);
        }
    })
}

for (i = 0; i < lagesElementer.length; i++) {
    lagesElementer[i].addEventListener('click', fullførOrdre)
}

let ferdigElementer = document.getElementById('ferdig').querySelectorAll('p');

function slettOrdre(evt) {
    $.ajax({
        url: '',
        method: 'POST',
        contentType: 'application/json',
        data: JSON.stringify({operasjon: 'slettOrdre', id: evt.target.id}),
        success: function (res) {
            evt.target.remove();
        }
    })
}

for (i = 0; i < ferdigElementer.length; i++) {
    ferdigElementer[i].addEventListener('click', slettOrdre);
}