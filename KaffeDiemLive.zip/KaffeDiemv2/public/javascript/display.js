let lages = document.getElementById('lages');
let ferdig = document.getElementById('ferdig');
let audio = new Audio('/media/ding.wav');
let eksisterendeLages = [];
lages.querySelectorAll('p').forEach(function (i) {eksisterendeLages.push(Number(i.id))});
let eksisterendeFerdig = [];
ferdig.querySelectorAll('p').forEach(function (i) {eksisterendeFerdig.push(Number(i.id))});

const socket = new WebSocket('ws://localhost:80');

socket.addEventListener('message', function (event) {
    data = JSON.parse(event.data);
    let spillLyd = 1;
    for (i = 0; i < data.length; i++) {
        if (data[i].operasjon === 'opprett') {
            if (eksisterendeLages.includes(data[i].id) == true) continue;
            eksisterendeLages.push(data[i].id);
            let ordreElement = document.createElement('p');
            ordreElement.innerHTML = ('000' + data[i].id).slice(-3);
            ordreElement.id = data[i].id;
            lages.appendChild(ordreElement);
        }
        else if (data[i].operasjon === 'flytt') {
            if (eksisterendeFerdig.includes(data[i].id) == true) continue;
            let gammeltElement = document.getElementById(data[i].id);
            if (gammeltElement != undefined) {
                gammeltElement.remove();
                eksisterendeLages.slice(eksisterendeLages.indexOf(data[i].id), 1);
                eksisterendeFerdig.push(data[i].id);
                let ordreElement = document.createElement('p');
                ordreElement.innerHTML = ('000' + data[i].id).slice(-3);
                ordreElement.id = data[i].id;
                ferdig.appendChild(ordreElement);
                if (spillLyd == 1) {
                    audio.play();
                    spillLyd = 0;
                }
            }
        }
        else if (data[i].operasjon === 'slett') {
            if (eksisterendeFerdig.includes(data[i].id) == false) continue;
            eksisterendeFerdig.slice(eksisterendeFerdig.indexOf(data[i].id, 1));
            let gammeltElement = document.getElementById(data[i].id)
            if (gammeltElement != undefined) {
                gammeltElement.remove();
            }
        }
    }
});