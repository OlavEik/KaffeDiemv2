document.getElementById('innlogging').addEventListener('submit', function (event) {
    event.preventDefault();
    $.ajax({
        url: '',
        method: 'POST',
        contentType: 'application/json',
        data: JSON.stringify({passord: document.getElementById('passord').value}),
        success: function (res) {
            if (!res.feilmelding) {
                window.location.pathname = '/';
            }
            if (res.feilmelding == 'For raskt') {
                document.getElementById('feilmelding').innerHTML = 'Vent 2 sekunder og prøv igjen';
            }
            if (res.feilmelding == 'Feil passord') {
                document.getElementById('passord').style.borderColor = 'red';
            }
        }
    })
})